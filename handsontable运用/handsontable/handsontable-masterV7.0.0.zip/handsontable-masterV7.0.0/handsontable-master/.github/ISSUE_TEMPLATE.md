### Description
<!--- Tell us what happens and what should happen -->

### Steps to reproduce
<!--- Provide steps to reproduce this issue -->
1.
2.
3.

### Demo
<!--- Provide a link to a live example on JSFiddle or Codepen or fill the following demo with your settings -->
https://jsfiddle.net/handsoncode/8ffpsqt6/

### Your environment
* Handsontable version:
* Browser Name and version:
* Operating System:

