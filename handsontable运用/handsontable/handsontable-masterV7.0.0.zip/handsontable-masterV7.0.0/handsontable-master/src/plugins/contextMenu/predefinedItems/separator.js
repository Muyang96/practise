export const KEY = '---------';

export default function separatorItem() {
  return {
    name: KEY
  };
}
